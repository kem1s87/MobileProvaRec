using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class UserScene2 : MonoBehaviour
{
    public TMP_Text txtError;
    public TMP_Text txtpassword;

    void Start()
    {
        txtError.text = PlayerPrefs.GetString("user");
        txtpassword.text = PlayerPrefs.GetString("password");


    }

    void Update()
    {
        
    }
}
