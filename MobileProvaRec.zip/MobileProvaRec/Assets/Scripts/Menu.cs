using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;


public class Menu : MonoBehaviour
{
    public TMP_InputField txtUser;
    public TMP_InputField txtpassword;
    public void LoadScenes(string cena)
    {
        PlayerPrefs.SetString("user", txtUser.text);
        PlayerPrefs.SetString("password", txtpassword.text);
        SceneManager.LoadScene(cena);
    }
}
