using UnityEngine;
using UnityEngine.UI;

public class Example : MonoBehaviour
{
    public Button m_ButtonPlay;

    void Start()
    {
        m_ButtonPlay.onClick.AddListener(TaskOnClick);

        void TaskOnClick()
        {
            Debug.Log("You have clicked the button!");
        }
    }
}
