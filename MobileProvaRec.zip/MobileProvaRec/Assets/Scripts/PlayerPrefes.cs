using UnityEngine;
using System.Collections;

public class test : MonoBehaviour
{
    private void Start()
    {
        PlayerPrefs.SetInt("MyfirstKey", 42);

        Debug.Log(PlayerPrefs.GetInt("MyFirstKey").ToString());
    }
}